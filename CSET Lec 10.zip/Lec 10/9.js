if (condition1) {
//code to be executed if condition1 is true
} else if (condition2) {
//if the condition1 is false and condition2 is true
} else {
//if the condition1 is false and condition2 is false
}

if (time < 10) {
greeting = "Good morning";
} else if (time < 20) {
greeting = "Good day";
} else {
greeting = "Good evening";
}
