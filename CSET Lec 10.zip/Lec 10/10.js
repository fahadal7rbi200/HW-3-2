switch(expression) {
case x:
// code block
break;
case y:
// code block
break;
default:
// code block
}

switch (new Date().getDay()) {
case 5:
text = "Today is Friday";
break;
case 6:
text = "Today is Saturday";
break;
default:
text = “Today is not a Weekend";
}

switch (new Date().getDay()) {
case 3:
case 4:
text = "Soon it is Weekend";
break;
case 5:
case 6:
text = "It is Weekend";
break;
default:
text = "Looking forward to the Weekend";
}
