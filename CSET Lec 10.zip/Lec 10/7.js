Math.abs (-3);  // returns 3

Math.ceil(4.7);  // returns 5

Math.foor(4.7);  // returns 4

Math.round(4.7);  // returns 5

Math.round(4.4); // returns 4

Math.max(8, 2);  // returns 8

Math.min(8, 2); // returns 2

Math.pow(8, 2);  // returns 64

Math.random();  // returns random

Math.sqrt(4);  // returns 2
