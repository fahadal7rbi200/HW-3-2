var x, y, z;  // Statement 1
x = 5;  // Statement 2
y = 6;  // Statement 3
z = x + y;  // Statement 4
