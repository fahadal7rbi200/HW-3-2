var x = 5;
var y = 2;

var a = x + y;
var b = x - y;
var c = x * y;
var d = x / y;
var e = x % y;
x++;  //value now is 6.
y--; //value now is 1.
