var length 16;  //Number
var lastName ="Johnson"  //String
var cars =[" Saab", "Volvo", "BMW"];  //Array
var x {firstName:"John", lastName:"Doe"};  //Object
