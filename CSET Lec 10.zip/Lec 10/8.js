var d = new Date("2015-03-25");
var d = new Date("03/25/2015");
var d = new Date("Mar 25 2015");
